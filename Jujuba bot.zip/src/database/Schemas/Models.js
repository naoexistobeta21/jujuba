module.exports = {
    guilds: require('./Guild'),
    users: require('./User.js'),
    fundos: require('./Fundo.js'),
    levelsroles: require('./Levelroles'),
    shop: require('./Shop'),
    shopitems: require('./ShopItems'),
    codes: require('./Codes')
}