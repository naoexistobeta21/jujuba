const { MessageEmbed } = require('discord.js')

class Player {
    constructor(id, coins) {
        this.id = id;
        this.coins = coins;
        this.status = false
        this.points = 0
    }

    poison(id, channel) {
        const embed = new MessageEmbed().setTitle(`<@${this.id}> Envenenou <@${id}>`).setImage('https://c.tenor.com/ARhzOw2NHfEAAAAC/adventure-time.gif').setFooter({ text: `O ataque tirou -10 de HP do usuário atacado.`})
        channel.send({ embeds: [embed]})
    }

    sendStatus(status) {
        this.status = status ? status : false
    }

    givePoints(points) {
        this.points = this.points + points
    }

    removePoints(points) {
        this.points = this.points - points
    }
}

exports.Player = Player;