const { MessageEmbed, MessageButton, MessageActionRow } = require('discord.js')
const coins = require('discord-mongo-currency')
const { Player } = require('./players')
class AdventureTime {
    constructor(players = []) {
        this.players = players;
        this.playersP = []
        this.message = null
        this.list = new Map()
    }

    async start(channel) {
            const embedADD = new MessageEmbed()
        .setTitle('Adventure Time!')
        .setDescription(`*Certo dia um homem chamado "Finn" criou uma gangue para deter as forças do mal, entre no jogo e ajude ele a vencer o Reino de Fogo!*`)
        .setFields(
            {
                name: 'Players',
                value: `Nenhum participante ainda...`
            }
        ) 
        .setColor('LUMINOUS_VIVID_PINK')
        .setFooter({ text: 'Preço de entrada: 2,000 caramelos | acaba em 18 minutos'})

        let button = new MessageButton()
        .setLabel('Play')
        .setCustomId('playAdv')
        .setStyle('SUCCESS')

        const row = new MessageActionRow().addComponents(button)

        let msg = await channel.send({ embeds: [embedADD], components: [row], fetchReply: true})
        this.message = msg.id
    }

    async next(channel) {
        let vencedor = this.players[~~(Math.random() * this.players.length)]
        await coins.giveCoins(vencedor, '968570313027780638', 2000 * this.players.length)
        channel.send({ content: `**Parabéns <@${vencedor}> , você acaba de ganhar ${2000 * this.players.length} caramelos, ${this.players.length - 1} players perderam 2,000 caramelos!**`})
        for(let i = 0; i < this.players.length; i++) {
            if(this.players[i] !== vencedor) {
                await coins.deductCoins(this.players[i], '968570313027780638', 2000)
            }
        }
        //60000 * 18 - 18 minutos
        for(let i = 0; i < this.players.length; i++) {
            this.list.delete(this.players[i])
        }
        this.playersP = []
    }

    addPlayer(i, playerId) {
        let t = this.list.get(playerId)
        if(t) console.log(t.id)
        if(t) return i.reply({ content: 'Aguarde até o próximo jogo', ephemeral: true})
        this.players.push(playerId);
        this.playersP.push(`<@${playerId}>`);

        this.list.set(`${playerId}`, new Player(playerId, 0))
        const embedADD = new MessageEmbed()
        .setTitle('Adventure Time!')
        .setDescription(`*Certo dia um homem chamado "Finn" criou uma gangue para deter as forças do mal, entre no jogo e ajude ele a vencer o Reino de Fogo!*`)
        .setFields(
            {
                name: 'Players',
                value: `${this.playersP.join("\n")}`
            }
        ) 
        .setColor('LUMINOUS_VIVID_PINK')
        .setFooter({ text: 'Preço de entrada: 2,000 caramelos | acaba em 18 minutos'})

        i.update({ embeds: [embedADD]})
    }
}

exports.AdventureTime = AdventureTime