const express = require('express');
const morgan = require('morgan');
const cors = require('cors');
const BodyParser = require('body-parser');
const cluster = require('../cluster')

const app = express();

app.use(morgan('dev'))
app.use(BodyParser.urlencoded({ extended: false }))
app.use(express.json())
app.use(cors())


app.listen(25568, () => {
    console.log('Api ligada com sucesso')
})





