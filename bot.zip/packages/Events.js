class SuperEv {
    sendEmbed(argumento) {
        
    }
}

module.exports = SuperEv;